﻿using EF.Matriculas.Tablas.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF.Matriculas.Tablas.Interfaces
{
    public interface IRepositorioNotas : IRepositorioGenerico<Notas>
    {

    }
}
