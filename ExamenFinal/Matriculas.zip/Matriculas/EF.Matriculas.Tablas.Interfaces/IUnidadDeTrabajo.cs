﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF.Matriculas.Tablas.Interfaces
{
    public interface IUnidadDeTrabajo : IDisposable
    {
        IRepositorioAlumno RepositorioAlumno { get; }
        IRepositorioUsers RepositorioUsers { get; }
        IRepositorioMatricula RepositorioMatricula { get; }
        int Complete();
    }
}
