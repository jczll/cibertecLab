﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF.Matriculas.Tablas.Interfaces
{
    public interface IRepositorioGenerico<TEntidad> where TEntidad : class
    {
        TEntidad ConsultarPorCodigo(int id);
        IEnumerable<TEntidad> ConsultaTodo();
        void Agregar(TEntidad entidad);
        void Eliminar(TEntidad entidad);
        void Actualizar(TEntidad entidad);
        int ContarRegistros();
    }
}
