﻿using EF.Matriculas.Consultas;
using EF.Matriculas.Tablas.Entidades;
using EF.Matriculas.Tablas.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF.Matriculas.Tablas.AccesoDatos
{
    public class RepositorioMatricula : RepositorioGenerico<Matricula>, IRepositorioMatricula
    {
        public RepositorioMatricula(DbContext pContext) : base(pContext)
        {

        }

        IEnumerable<AlumnoMatriculado> IRepositorioMatricula.BuscarAlumnoMatriculado(int iGradoID, int iSeccionID, int iAlumnoID)
        {
            var param1 = new SqlParameter();
            param1.ParameterName = "@GradoID";
            param1.Value = iGradoID;
            var param2 = new SqlParameter();
            param2.ParameterName = "@SeccionID";
            param2.Value = iSeccionID;
            var param3 = new SqlParameter();
            param3.ParameterName = "@AlumnoID";
            param3.Value = iAlumnoID;

            return this.context.Database.SqlQuery<AlumnoMatriculado>("sp_BuscarAlumnoMatriculado @GradoID, @SeccionID, @AlumnoID", param1, param2, param3).ToList();
        }
    }
}
