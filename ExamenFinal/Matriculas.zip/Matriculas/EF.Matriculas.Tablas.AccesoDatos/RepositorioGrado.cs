﻿using EF.Matriculas.Tablas.Entidades;
using EF.Matriculas.Tablas.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF.Matriculas.Tablas.AccesoDatos
{
    public class RepositorioGrado : RepositorioGenerico<Grado>, IRepositorioGrado
    {
        public RepositorioGrado(DbContext pContext) : base(pContext)
        {

        }
    }
}
