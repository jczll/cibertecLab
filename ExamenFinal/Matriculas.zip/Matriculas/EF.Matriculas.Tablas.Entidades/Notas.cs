namespace EF.Matriculas.Tablas.Entidades
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Runtime.Serialization;

    [DataContract]
    [Table("Notas")]
    public partial class Notas
    {
        [DataMember]
        [Key]
        public int NotaID { get; set; }

        [DataMember]
        public int? AlumnoID { get; set; }

        [DataMember]
        [Column(TypeName = "numeric")]
        public decimal? Nota { get; set; }

        [DataMember]
        public virtual Alumno Alumno { get; set; }
    }
}
