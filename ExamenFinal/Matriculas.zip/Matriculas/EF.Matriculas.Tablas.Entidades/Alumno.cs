namespace EF.Matriculas.Tablas.Entidades
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;    
    using System.Runtime.Serialization;

    [DataContract]
    [Table("Alumno")]
    public partial class Alumno
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Alumno()
        {
            Matricula = new HashSet<Matricula>();
            Notas = new HashSet<Notas>();
        }

        [DataMember]
        public int AlumnoID { get; set; }

        [DataMember]
        [StringLength(50)]
        public string Nombres { get; set; }

        [DataMember]
        [StringLength(50)]
        public string Apellidos { get; set; }

        [DataMember]
        [StringLength(90)]
        public string Direccion { get; set; }

        [DataMember]
        [StringLength(1)]
        public string Sexo { get; set; }

        [DataMember]
        public DateTime? FechNacimiento { get; set; }

        [DataMember]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Matricula> Matricula { get; set; }

        [DataMember]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Notas> Notas { get; set; }
    }
}
