namespace EF.Matriculas.Tablas.Entidades
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Runtime.Serialization;

    [DataContract]
    [Table("Curso")]
    public partial class Curso
    {
        [DataMember]
        public int CursoID { get; set; }

        [DataMember]
        public int? GradoID { get; set; }

        [DataMember]
        [StringLength(50)]
        public string Nombre { get; set; }

        [DataMember]
        public virtual Grado Grado { get; set; }
    }
}
