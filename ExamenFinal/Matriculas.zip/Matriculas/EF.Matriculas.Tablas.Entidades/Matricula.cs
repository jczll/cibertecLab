namespace EF.Matriculas.Tablas.Entidades
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Runtime.Serialization;

    [DataContract]
    [Table("Matricula")]
    public partial class Matricula
    {
        [DataMember]
        public int MatriculaID { get; set; }

        [DataMember]
        public DateTime? Fecha { get; set; }

        [DataMember]
        public int? GradoID { get; set; }

        [DataMember]
        public int? SeccionID { get; set; }

        [DataMember]
        public int? AlumnoID { get; set; }

        [DataMember]
        public virtual Alumno Alumno { get; set; }

        [DataMember]
        public virtual Grado Grado { get; set; }

        [DataMember]
        public virtual Seccion Seccion { get; set; }
    }
}
