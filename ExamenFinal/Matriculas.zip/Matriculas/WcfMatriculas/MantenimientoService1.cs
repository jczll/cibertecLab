﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Matriculas.AccesoDatos;
using Matriculas.Consultas;
using Matriculas.Entidades;
using Matriculas.Interfaces;

namespace WcfMatriculas
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código y en el archivo de configuración a la vez.
    public class MantenimientoService1 : IMantenimientoService1
    {
        private readonly IUnidadDeTrabajo unidadDeTrabajo;
        private readonly DbContext dbContext;

        public MantenimientoService1()
        {
            dbContext = new MatriculasModel();
            unidadDeTrabajo = new UnidadDeTrabajo(dbContext);
        }

        public bool ActualizarAlumno(Alumno alumno)
        {
            unidadDeTrabajo.RepositorioAlumno.Actualizar(alumno);
            unidadDeTrabajo.Complete();
            return true;
        }

        public bool AgregarAlumno(Alumno alumno)
        {
            unidadDeTrabajo.RepositorioAlumno.Agregar(alumno);
            unidadDeTrabajo.Complete();
            return true;
        }

        public int AgregarMatricula(Matricula matricula)
        {
            unidadDeTrabajo.RepositorioMatricula.Agregar(matricula);
            unidadDeTrabajo.Complete();
            return matricula.MatriculaID;
        }

        public IEnumerable<AlumnoMatriculado> BuscarAlumnoMatriculado(int iGradoID, int iSeccionID, int iAlumnoID)
        {
            var data = unidadDeTrabajo.RepositorioMatricula.BuscarAlumnoMatriculado(iGradoID, iSeccionID, iAlumnoID).Take(1);
            return data;
        }

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public IEnumerable<Alumno> ObtenerAlumnoPorNombre(string sNombres)
        {
            return unidadDeTrabajo.RepositorioAlumno.ConsultaPorAlumno(sNombres);
        }

        public Alumno ObtenerAlumnoxID(int id)
        {
            var alumno = unidadDeTrabajo.RepositorioAlumno.ConsultarPorCodigo(id);
            return alumno;
        }

        public Users ObtenerUsuarioPorLogin(string login, string password)
        {
            return unidadDeTrabajo.RepositorioUsers.ObtenerUsuarioPorLogin(login, password);
        }
    }
}
