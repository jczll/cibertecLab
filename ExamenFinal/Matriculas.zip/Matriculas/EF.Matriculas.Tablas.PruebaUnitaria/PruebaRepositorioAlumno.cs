﻿using System;
using System.Data.Entity;
using System.Linq;
using EF.Matriculas.Tablas.AccesoDatos;
using EF.Matriculas.Tablas.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EF.Matriculas.Tablas.PruebaUnitaria
{
    [TestClass]
    public class PruebaRepositorioAlumno
    {
        private readonly DbContext dbcontext;
        private readonly IRepositorioAlumno RepositorioAlumno;
        private readonly IUnidadDeTrabajo unidadDeTrabajo;

        public PruebaRepositorioAlumno()
        {
            this.dbcontext = new MatriculasModel();
            RepositorioAlumno = new RepositorioAlumno(dbcontext);
            unidadDeTrabajo = new UnidadDeTrabajo(dbcontext);
        }

        [TestMethod]
        public void ObtenerAlumnoPorNombre()
        {
            var cantidad = unidadDeTrabajo.RepositorioAlumno.ConsultaPorAlumno("D").Count();
            Assert.IsTrue(cantidad > 0, "Ok");
        }
    }
}
