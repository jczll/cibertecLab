﻿using Matriculas.Consultas;
using Matriculas.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriculas.Interfaces
{
    public interface IRepositorioMatricula : IRepositorioGenerico<Matricula>
    {
        IEnumerable<AlumnoMatriculado> BuscarAlumnoMatriculado(int iGradoID, int iSeccionID, int iAlumnoID);
    }
}
