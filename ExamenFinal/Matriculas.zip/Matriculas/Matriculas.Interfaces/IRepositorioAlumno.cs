﻿using Matriculas.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriculas.Interfaces
{
    public interface IRepositorioAlumno : IRepositorioGenerico<Alumno>
    {
        IEnumerable<Alumno> ConsultaPorAlumno(string sNombres);
    }
}
