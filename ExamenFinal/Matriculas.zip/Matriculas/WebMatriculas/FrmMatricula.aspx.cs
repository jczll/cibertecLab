﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using WebMatriculas.MantenimientoService;


namespace WebMatriculas
{
    public partial class FrmMatricula : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TxtFecha.Text = Convert.ToString(DateTime.Now);
            if (!String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {
                CmbAlumnoID.Text = Request.QueryString["id"];
                CmbAlumnoID.Enabled = false;
            }
        }
        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (ValidaAlumnoMatriculado() == 0)
            {
                if (GuardarMatricula() > 0)
                    MessageBox.Show("Su Matricula fue Guardada en forma Satisfactoria", "Cibertec", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("No se pudo guardar su Matricula ", "Cibertec", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("El Alumno Ya esta Matriculado para ese Curso y ese Grado ", "Cibertec", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }
        private int GuardarMatricula()
        {
            var servicio = new MantenimientoService.MantenimientoService1Client();
            var iMatriculaId = servicio.AgregarMatricula(
                new Matricula()
                {
                    Fecha   = DateTime.Now,
                    GradoID = Convert.ToInt32(CmbGradoID.Text),
                    SeccionID = Convert.ToInt32(CmbSeccionID.Text),
                    AlumnoID = Convert.ToInt32(CmbAlumnoID.Text)
                }
            );
            return iMatriculaId;
        }
        private int ValidaAlumnoMatriculado()
        {
            var servicio = new MantenimientoService.MantenimientoService1Client();
            var AlumnoMatriculado = servicio.BuscarAlumnoMatriculado(Convert.ToInt32(CmbGradoID.Text), Convert.ToInt32(CmbSeccionID.Text), Convert.ToInt32(CmbAlumnoID.Text));
            return AlumnoMatriculado.Count();
        }
    }
}