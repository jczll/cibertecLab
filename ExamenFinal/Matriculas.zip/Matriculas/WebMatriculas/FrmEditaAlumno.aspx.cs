﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebMatriculas.MantenimientoService;

namespace WebMatriculas
{
    public partial class FrmEditaAlumno : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ObtenerAlumno();
            }
        }

        private void ObtenerAlumno()
        {
            if (String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {
                return;
            }
            else
            {
                var id = Convert.ToInt32(Request.QueryString["id"]);
                var servicio = new MantenimientoService.MantenimientoService1Client();                ;
                //Obteniendo la informacion Completa del Alumno
                var alumno = servicio.ObtenerAlumnoxID(id);
                TxtNombres.Text = alumno.Nombres;
                TxtApellidos.Text = alumno.Apellidos;
                TxtDireccion.Text = alumno.Direccion;
                TxtSexo.Text = alumno.Sexo;
                TxtFechNac.Text= alumno.FechNacimiento.ToString();
                HFId.Value = alumno.AlumnoID.ToString();
            }
        }

        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            Guardar();
        }
        private void Guardar()
        {
            var servicio = new MantenimientoService.MantenimientoService1Client();
            if (string.IsNullOrWhiteSpace(HFId.Value))  //Nuevo
            {
                servicio.AgregarAlumno(
                    new Alumno()
                    {
                        Nombres = TxtNombres.Text,
                        Apellidos =TxtApellidos.Text,
                        Direccion =TxtDireccion.Text,
                        Sexo      = TxtSexo.Text,
                        FechNacimiento   =Convert.ToDateTime(TxtFechNac.Text)
                    }
                );
            }
            else //Edicion
            {
                servicio.ActualizarAlumno(
                    new Alumno()
                    {
                        AlumnoID = Convert.ToInt32(HFId.Value),
                        Nombres = TxtNombres.Text,
                        Apellidos = TxtApellidos.Text,
                        Direccion = TxtDireccion.Text,
                        Sexo = TxtSexo.Text,
                        FechNacimiento = Convert.ToDateTime(TxtFechNac.Text)
                    });
            }
            Session["Alumno"] = null;
            Response.Redirect("FrmConsultaAlumnos");
        }
    }
}