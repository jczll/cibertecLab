-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create procedure [dbo].[sp_BuscarAlumnoMatriculado] 
@GradoID int,
@SeccionID int,
@AlumnoID int
as
begin 
select Count(*) as Cantidad from Matricula 
                            where GradoID=@GradoID and SeccionID=@SeccionID and AlumnoID=@AlumnoID 
end