﻿using EF.Matriculas.Tablas.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web.Matriculas.ServiciosMatriculas;

namespace Web.Matriculas
{
    public partial class FrmConsultaAlumnos : PaginaBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
                Consultar();
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            Cache.Remove("AlumnoCache");
            //Session["Alumno"] = null;
            Consultar();
        }

        protected void GrdTablas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdTablas.PageIndex = e.NewPageIndex;
            Consultar();
        }
        private void Consultar()
        {
            var servicio = new ServiciosMatriculas.MatriculaServiciosClient();
            Alumno[] data;
            if (Cache["AlumnoCache"] == null)
            {
                data = servicio.ObtenerAlumnoPorNombre(TxtConsultaXNombre.Text.Trim());
                Cache.Insert("ArtistCache", data, null, DateTime.Now.AddSeconds(30), System.Web.Caching.Cache.NoSlidingExpiration);
            }
            else
            {
                data = Cache["Alumno"] as Alumno[];
            }
            //dynamic data = null;
            //if (Session["Alumno"] == null)
            //{
            //    var servicio = new ServiciosMatriculas.MatriculaServiciosClient();
            //    data = servicio.ObtenerAlumnoPorNombre(TxtConsultaXNombre.Text.Trim());
            //    Session["Alumno"] = data;
            //}
            //else
            //{
            //    data = Session["Alumno"] as Alumno[];
            //}
            GrdTablas.DataSource = data;
            GrdTablas.DataBind();
        }

        protected void BtnNuevo_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmEditaAlumno.aspx");
        }
    }
}