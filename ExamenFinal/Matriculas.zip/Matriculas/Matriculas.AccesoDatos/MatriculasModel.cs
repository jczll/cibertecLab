namespace Matriculas.AccesoDatos
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using Matriculas.Entidades;

    public partial class MatriculasModel : DbContext
    {
        public MatriculasModel()
            : base("name=MatriculasModel1")
        {
            this.Configuration.ProxyCreationEnabled = false;
        }

        public virtual DbSet<Alumno> Alumno { get; set; }
        public virtual DbSet<Curso> Curso { get; set; }
        public virtual DbSet<Grado> Grado { get; set; }
        public virtual DbSet<Matricula> Matricula { get; set; }
        public virtual DbSet<Notas> Notas { get; set; }
        public virtual DbSet<Seccion> Seccion { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Alumno>()
                .Property(e => e.Nombres)
                .IsUnicode(false);

            modelBuilder.Entity<Alumno>()
                .Property(e => e.Apellidos)
                .IsUnicode(false);

            modelBuilder.Entity<Alumno>()
                .Property(e => e.Direccion)
                .IsUnicode(false);

            modelBuilder.Entity<Alumno>()
                .Property(e => e.Sexo)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Curso>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<Grado>()
                .Property(e => e.Nivel)
                .IsUnicode(false);

            modelBuilder.Entity<Notas>()
                .Property(e => e.Nota)
                .HasPrecision(18, 0);

            modelBuilder.Entity<Seccion>()
                .Property(e => e.Nombre)
                .IsUnicode(false);
        }
    }
}
