﻿using Matriculas.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriculas.AccesoDatos
{
    public class UnidadDeTrabajo : IUnidadDeTrabajo
    {
        private readonly DbContext _context;
        public IRepositorioAlumno RepositorioAlumno { get; private set; }
        public IRepositorioUsers RepositorioUsers { get; private set; }
        public IRepositorioMatricula RepositorioMatricula { get; private set; }

        public UnidadDeTrabajo(DbContext context)
        {
            _context = context;
            RepositorioAlumno = new RepositorioAlumno(_context);
            RepositorioUsers = new RepositorioUsers(_context);
            RepositorioMatricula = new RepositorioMatricula(_context);
        }
        public int Complete()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
