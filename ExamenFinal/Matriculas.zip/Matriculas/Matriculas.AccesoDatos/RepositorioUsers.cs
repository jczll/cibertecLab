﻿using Matriculas.Entidades;
using Matriculas.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriculas.AccesoDatos
{
    public class RepositorioUsers : RepositorioGenerico<Users>, IRepositorioUsers
    {
        public RepositorioUsers(DbContext pContext) : base(pContext)
        {

        }

        public Users ObtenerUsuarioPorLogin(string login, string password)
        {
            return this.context.Set<Users>()
                .Where(item => item.Login == login && item.Password == password)
                .FirstOrDefault();
        }
    }
}
