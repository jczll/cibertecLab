﻿using Matriculas.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriculas.AccesoDatos
{
    public class RepositorioGenerico<TEntidad> : IRepositorioGenerico<TEntidad> where TEntidad : class
    {
        protected readonly DbContext context;
        public RepositorioGenerico(DbContext pContext)
        {
            this.context = pContext;
        }
        public void Actualizar(TEntidad entidad)
        {
            this.context.Set<TEntidad>().Attach(entidad);
            this.context.Entry<TEntidad>(entidad).State = EntityState.Modified;
        }

        public void Agregar(TEntidad entidad)
        {
            this.context.Set<TEntidad>().Add(entidad);
        }

        public TEntidad ConsultarPorCodigo(int id)
        {
            return this.context.Set<TEntidad>().Find(id);
        }

        public IEnumerable<TEntidad> ConsultaTodo()
        {
            return this.context.Set<TEntidad>().ToList();
        }

        public int ContarRegistros()
        {
            throw new NotImplementedException();
        }

        public void Eliminar(TEntidad entidad)
        {
            this.context.Set<TEntidad>().Attach(entidad);
            this.context.Set<TEntidad>().Remove(entidad);
        }
    }
}
