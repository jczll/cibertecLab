﻿using Matriculas.Entidades;
using Matriculas.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriculas.AccesoDatos
{
    public class RepositorioAlumno : RepositorioGenerico<Alumno>, IRepositorioAlumno
    {
        public RepositorioAlumno(DbContext pContext) : base(pContext)
        {

        }
        public IEnumerable<Alumno> ConsultaPorAlumno(string sNombres)
        {
            return ((MatriculasModel)context).Alumno.Where(item => item.Nombres.Contains(sNombres)).ToList();
        }
    }
}
