namespace Matriculas.Entidades
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Curso")]
    public partial class Curso
    {
        public int CursoID { get; set; }

        public int? GradoID { get; set; }

        [StringLength(50)]
        public string Nombre { get; set; }

        public virtual Grado Grado { get; set; }
    }
}
