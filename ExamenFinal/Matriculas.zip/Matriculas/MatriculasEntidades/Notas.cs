namespace Matriculas.Entidades
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Notas
    {
        [Key]
        public int NotaID { get; set; }

        public int? AlumnoID { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? Nota { get; set; }

        public virtual Alumno Alumno { get; set; }
    }
}
